package Calci;

import java.util.*;

public class Calculator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean keepRunning = true;
		
		while(keepRunning) {
			System.out.println("\n==== Calculator ====");
			System.out.println("\n1. Basic Arithmetic Operations");
			System.out.println("2. Scientific Calculations");
			System.out.println("3. Exchange Rate");
			System.out.println("4. Unit Conversions");
			System.out.println("5. Exit");
			System.out.println("\nChoose an Option");
			
			int choice = sc.nextInt();
			switch(choice) {
			case 1 : 
				basicOperations(sc);
				break;
			case 2 :
				scientificOperations(sc);
				break;
			case 3 :
				exchangeRate(sc);
				break;
			case 4 :
				unitConversions(sc);
				break;
			case 5 : 
				keepRunning = false;
				System.out.println("Exiting calculator!....\n Goodbye!");
				break;
			default :
				System.out.println("Invalid Option. Please try again");
			}
		}
		sc.close();
	}
		
		public static void basicOperations(Scanner sc) {
			double num1, num2;
			System.out.println("\n--- Basic Arithmetic ---");
			System.out.println("\n1. Addition\n2. Substraction\n3. Multication\n4. Division");
			System.out.println("Choose an Operation: ");
			int choice = sc.nextInt();
			
			System.out.println("Enter first number : ");
			num1 = sc.nextDouble();
			System.out.println("Enter second number : ");
			num2 = sc.nextDouble();
			
			switch(choice) {
			case 1 :
				System.out.println("Result: " + (num1 + num2));
				break;
			case 2 :
				System.out.println("Result: " + (num1 - num2));
				break;
			case 3 :
				System.out.println("Result: " + (num1 * num2));
				break;
			case 4 :
				if(num2 != 0)
				System.out.println("Result: " + (num1 / num2));
				else
				System.out.println("Error: Division by zero.");
				break;
			default :
				System.out.println("Invalid choice.");
			}
			System.out.println("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
		}
		
		public static void scientificOperations(Scanner sc) {
			double num1, num2;
			System.out.println("\n--- Scientific Operations ---");
			System.out.println("\n1. Square root\n2. Exponent\n3. Sin\n4. Cos\n5. Tan\n6. Cosec\n7. Sec\n8. Cot\n9. Log (base 10)\n10. Factorial");
			System.out.println("Choose an Operation: ");
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1 :
				System.out.println("Enter number : ");
				num1 = sc.nextDouble();
				if(num1 >= 0)
				System.out.println("Square root: " + Math.sqrt(num1));
				else
					System.out.println("Square root of negative number cannot possible...");
				break;
			case 2 :
				System.out.println("Enter base and exponent : ");
				num1 = sc.nextDouble();
				num2 = sc.nextDouble();
				System.out.println("Result: " + Math.pow(num1, num2));
				break;
			case 3 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("sin: " + Math.sin(num1));
				break;
			case 4 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("cos: " + Math.cos(num1));
				break;
			case 5 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("tan: " + Math.tan(num1));
				break;
			case 6 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("cosec: " + 1/(Math.sin(num1)));
				break;
			case 7 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("sec: " + 1/(Math.cos(num1)));
				break;
			case 8 :
				System.out.println("Enter angle in degrees: ");
				num1 = Math.toRadians(sc.nextDouble());
				System.out.println("cot: " + 1/(Math.tan(num1)));
				break;
			case 9 :
				System.out.println("Enter a positive number: ");
				num1 = sc.nextDouble();
				if(num1 > 0)
					System.out.println("log10: " + Math.log10(num1));
				else
					System.out.println("Error: Logarithm undefined for negative numbers.");
				break;
			case 10 :
				System.out.println("Enter a positive Integer: ");
				int n = sc.nextInt();
				if(n >= 0)
					System.out.println("Factorial: " +factorial(n));
				else
					System.out.println("Error: Factorial undefined for negative numbers.");
				break;
				default :
					System.out.println("Invalid choice.");
			}
			System.out.println("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
		}
		
		public static void exchangeRate(Scanner scanner) {
			System.out.println("\n--- Exchange Rate ---");
			System.out.println("\n1. Indian Rupees(INR) to US Dollar(USD)");
			System.out.println("2. US Dollar(USD) to Indian Rupees(INR)");
			System.out.println("3. Indian Rupees(INR) to Korean Won(KRW)");
			System.out.println("4. Korean Won(KRW) to Indian Rupees(INR)");
			System.out.println("5. Indian Rupees(INR) to Thai Baht(THB)");
			System.out.println("6. Thai Baht(THB) to Indian Rupees(INR)");
			int choice = scanner.nextInt();
			long input;
			switch (choice) {
            case 1:
                System.out.print("Enter Indian Rupees: ");
                input = scanner.nextLong();
                System.out.println("US Dollar: " + (input * 0.0117));
                break;
            case 2:
                System.out.print("Enter US Dollar: ");
                input = scanner.nextLong();
                System.out.println("Indian Rupees: " + (input * 85.3016));
                break;
            case 3:
                System.out.print("Enter Indian Rupees: ");
                input = scanner.nextLong();
                System.out.println("Korean Won: " + (input * 16.084));
                break;
            case 4:
                System.out.print("Enter Korean Won: ");
                input = scanner.nextLong();
                System.out.println("Indian Rupees: " + (input * 0.0622));
                break;
            case 5:
                System.out.print("Enter Indian Rupees: ");
                input = scanner.nextLong();
                System.out.println("Thai Baht: " + (input * 0.3815));
                break;
            case 6:
                System.out.print("Enter Thai Baht: ");
                input = scanner.nextLong();
                System.out.println("Indian Rupees: " + (input * 2.6209));
                break;
            default:
                System.out.println("Invalid choice.");
			}
			System.out.println("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
		}
		public static void unitConversions(Scanner scanner) {
	        System.out.println("\n--- Unit Conversions ---");
	        System.out.println("\n1. Meters to Kilometers");
	        System.out.println("2. Kilometers to Meters");
	        System.out.println("3. Centimeters to Inches");
	        System.out.println("4. Inches to Centimeters");
	        System.out.println("5. Kilograms to Pounds");
	        System.out.println("6. Pounds to Kilograms");
	        System.out.print("Choose a conversion: ");
	        int choice = scanner.nextInt();
	        double input;

	        switch (choice) {
	            case 1:
	                System.out.print("Enter meters: ");
	                input = scanner.nextDouble();
	                System.out.println("Kilometers: " + (input / 1000));
	                break;
	            case 2:
	                System.out.print("Enter kilometers: ");
	                input = scanner.nextDouble();
	                System.out.println("Meters: " + (input * 1000));
	                break;
	            case 3:
	                System.out.print("Enter centimeters: ");
	                input = scanner.nextDouble();
	                System.out.println("Inches: " + (input / 2.54));
	                break;
	            case 4:
	                System.out.print("Enter inches: ");
	                input = scanner.nextDouble();
	                System.out.println("Centimeters: " + (input * 2.54));
	                break;
	            case 5:
	                System.out.print("Enter kilograms: ");
	                input = scanner.nextDouble();
	                System.out.println("Pounds: " + (input * 2.20462));
	                break;
	            case 6:
	                System.out.print("Enter pounds: ");
	                input = scanner.nextDouble();
	                System.out.println("Kilograms: " + (input / 2.20462));
	                break;
	            default:
	                System.out.println("Invalid choice.");
	        }
	        System.out.println("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
	    }

	    public static long factorial(int num) {
	        long fact = 1;
	        for (int i = 2; i <= num; i++) {
	            fact *= i;
	        }
	        return fact;
	}
}

